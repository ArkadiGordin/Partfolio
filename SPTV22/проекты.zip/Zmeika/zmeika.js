var FIELD_SIZE_X = 20;
var FIELD_SIZE_Z = 20;
var SNAKE_SPEED = 300;
var snake = [];
var direction = 'y+';
var snake_timer;
var food_time;
var score = 0;

function init() {
    prepareGameField();

    var warp = document.getElementsByClassName('warp')[0];

    warp.style.width = '400px';

    document.getElementById('snake-start').addEventListener('click', startGame);
    document.getElementById('snake-renew').addEventListener('klik', refreshGame);


    addEventListener('keydown', changeDirection);

}


function prepareGameField() {

    var game_table = document.createElement('table');
        game_table.setAttribute('class', 'game-table');
        
}